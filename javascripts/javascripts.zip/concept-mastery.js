// docs/javascripts/concept-mastery.js
(function () {
  const LS_KEY = "concept_mastery_v1";

  const M_FULL = 3;
  const M_KNOW = 2;
  const M_FUZZY = 1;
  const M_DONT = 0;

  const SCORE_FULL = -2.2;
  const SCORE_KNOW = -0.3;
  const SCORE_FUZZY = 0.4;
  const SCORE_DONT = 1.8;
  const SCORE_K = 0.8;
  const HALF_LIFE_DAYS = 7;
  const CONF_SCALE = 6;
  const UNRATED_WEIGHT = 1.25;
  const WEIGHT_MIN = 0.06;
  const WEIGHT_MAX = 6.5;
  const HISTORY_LIMIT = 120;

  function normId(id) {
    return String(id || "").split("#")[0].replace(/^\/+/, "").trim();
  }

  const MEMORY_KEY = "__mkConceptMasteryMemoryV2";

  function masteryMemory() {
    try {
      const obj = window[MEMORY_KEY];
      if (obj && typeof obj === "object" && !Array.isArray(obj)) return obj;
    } catch (_) {}
    try { window[MEMORY_KEY] = {}; return window[MEMORY_KEY]; } catch (_) { return {}; }
  }

  function setMasteryMemory(obj) {
    try {
      window[MEMORY_KEY] = (obj && typeof obj === "object" && !Array.isArray(obj)) ? Object.assign({}, obj) : {};
    } catch (_) {}
  }

  function reclaimMasteryStorageSpace() {
    // These keys are disposable UI/cache ledgers.  They can grow large on one
    // browser profile and block both mastery writes and timed shop trials.
    const exact = [
      "mk_account_data_file_backup_v1",
      "mk_account_sync_last_result_v2",
      "mk_account_json_sync_last_summary_v1",
      "mk_account_sync_confirmed_cloud_v1",
      "mk_search_history_v1",
      "mk_search_suggestion_cache_v1"
    ];
    const prefixes = [
      "mk_search_history",
      "mk_search_suggest",
      "mk_account_xp_cache",
      "mk_hot_cache",
      "mk_ai_quiz_xp_seen",
      "mk_account_sync_last_summary"
    ];
    try {
      exact.forEach((key) => { try { localStorage.removeItem(key); } catch (_) {} });
      for (let i = localStorage.length - 1; i >= 0; i -= 1) {
        const key = localStorage.key(i);
        if (!key || key === LS_KEY || key === "mk_account_data_file_v1") continue;
        if (prefixes.some((prefix) => key.indexOf(prefix) === 0)) {
          try { localStorage.removeItem(key); } catch (_) {}
        }
      }
    } catch (_) {}
    try {
      if (window.MkAccountData && typeof window.MkAccountData.compactForStorage === "function") {
        window.MkAccountData.compactForStorage();
      }
    } catch (_) {}
  }

  function safeReadAll() {
    let stored = {};
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) {
        const obj = JSON.parse(raw);
        if (obj && typeof obj === "object" && !Array.isArray(obj)) stored = obj;
      }
    } catch (_) {}
    const mem = masteryMemory();
    return Object.assign({}, stored, mem);
  }

  function safeWriteAll(obj) {
    const clean = (obj && typeof obj === "object" && !Array.isArray(obj)) ? obj : {};
    setMasteryMemory(clean);
    let payload = "{}";
    try { payload = JSON.stringify(clean); } catch (_) { return false; }

    const tryWrite = () => {
      try {
        localStorage.setItem(LS_KEY, payload);
        return localStorage.getItem(LS_KEY) === payload;
      } catch (_) {
        return false;
      }
    };

    if (tryWrite()) return true;
    reclaimMasteryStorageSpace();
    if (tryWrite()) return true;

    try {
      window.dispatchEvent(new CustomEvent("mk-storage-write-problem", { detail: { key: LS_KEY, source: "concept-mastery" } }));
    } catch (_) {}
    return false;
  }

  function queueMasteryXpFallback(d) {
    try {
      const key = "mk_xp_pending_activity_queue_v1";
      const arr = JSON.parse(localStorage.getItem(key) || "[]");
      arr.push({ metric: "mastery", details: d || {}, opts: { path: d && (d.path || d.conceptId || d.concept_id), scope: `mastery:${d && (d.path || d.conceptId || d.concept_id || "concept")}:${d && (d.ts || Date.now())}`, throttleMs: 0 }, queuedAt: Date.now(), source: "concept-mastery-fallback" });
      localStorage.setItem(key, JSON.stringify(arr.slice(-300)));
    } catch (_) {}
  }

  function notifyChanged(detail) {
    const d = detail && typeof detail === "object" ? detail : {};
    let shouldRecordXp = false;
    let hasLevelValue = false;
    let changeKind = "";
    try {
      const kind = String(d.kind || d.type || d.event || d.action || "").toLowerCase().trim();
      changeKind = String(d.changeKind || d.change_kind || "").toLowerCase().trim();
      hasLevelValue = d.level != null || d.mastery != null;
      const isExplicitMasteryChange = !!(d.ratingChanged || d.hasRating || d.hadRating || ["create", "change", "same", "clear"].includes(changeKind) || hasLevelValue);
      shouldRecordXp = !!(d.source !== "cloud-sync" && kind !== "view" && kind !== "visit" && kind !== "seen" && isExplicitMasteryChange);
      if (shouldRecordXp && window.MkAccountData && typeof window.MkAccountData.recordMastery === "function") {
        window.MkAccountData.recordMastery(d.path || d.conceptId || d.concept_id, hasLevelValue ? (d.level != null ? d.level : d.mastery) : null, d, { source: d.source || d.via || "concept-mastery", clear: changeKind === "clear" });
        shouldRecordXp = false;
      }
    } catch (_) {}
    try {
      if (shouldRecordXp && window.MkXpActivity && typeof window.MkXpActivity.record === "function") {
        window.MkXpActivity.record("mastery", Object.assign({ source: "concept-mastery-fallback-api" }, d));
        shouldRecordXp = false;
      }
    } catch (_) {}
    if (shouldRecordXp) queueMasteryXpFallback(d);
    try {
      window.dispatchEvent(new CustomEvent("conceptMasteryChanged", { detail: d }));
    } catch (_) {}
  }

  function masteryChangeDetail(key, prev, next, source, ts, meta, opts) {
    const before = normaliseRecord(prev);
    const after = normaliseRecord(next);
    const hadRating = before && before.unrated !== true && validLevel(before.m);
    const hasRating = after && after.unrated !== true && validLevel(after.m);
    const oldM = hadRating ? Number(before.m) : null;
    const newM = hasRating ? Number(after.m) : null;
    const changed = hasRating && (!hadRating || oldM !== newM);
    return {
      conceptId: key,
      path: key,
      title: cleanTitle((meta && meta.title) || after.title || before.title || ""),
      course: (meta && meta.course) || after.course || before.course || "",
      coursePath: (meta && meta.coursePath) || after.coursePath || before.coursePath || "",
      source: source || "mastery",
      ts: Number(ts) || Date.now(),
      level: newM,
      mastery: newM,
      oldLevel: oldM,
      oldMastery: oldM,
      hadRating: !!hadRating,
      hasRating: !!hasRating,
      ratingChanged: !!changed,
      xpEligible: !!changed,
      // If there was already a mastery state, changing it should be scored as a
      // repeated mastery action.  This flag is consumed by the XP calculator so
      // restored history and direct events use the same 30% repeat rule.
      forceRepeat: !!(changed && hadRating),
      repeatOnly: !!(changed && hadRating),
      changeKind: !hasRating ? "clear" : (!hadRating ? "create" : (oldM !== newM ? "change" : "same")),
      via: opts && opts.via || opts && opts.source || source || "mastery"
    };
  }

  function emptyCounts() {
    return { full: 0, know: 0, fuzzy: 0, dont: 0 };
  }

  function validLevel(m) {
    return [M_FULL, M_KNOW, M_FUZZY, M_DONT].includes(Number(m));
  }

  function parseMaybeLevel(m) {
    if (m === null || m === "" || typeof m === "undefined") return null;
    const mm = Number(m);
    return validLevel(mm) ? mm : null;
  }

  function cleanTitle(s) {
    const t = String(s || "");
    return t.replace(/\s*\u00B6\s*$/u, "").replace(/\s*¶\s*$/u, "").trim();
  }

  function historyTs(item) {
    return Number(item && (item.ts || item.time || item.at || item.date)) || 0;
  }

  function historyKind(item) {
    const kind = String(item && (item.kind || item.type || item.event || item.action) || "").toLowerCase().trim();
    if (kind === "view" || kind === "visit" || kind === "seen") return "view";
    return "mastery";
  }

  function normaliseHistory(history, currentLevel, lastReviewed, reviewCount, lastViewed) {
    const src = Array.isArray(history) ? history : [];
    const out = [];

    for (const item of src) {
      const ts = historyTs(item);
      if (!ts) continue;

      const kind = historyKind(item);
      const source = typeof item?.source === "string" ? item.source : "";
      const visitId = typeof item?.visitId === "string" ? item.visitId : "";

      if (kind === "view") {
        out.push({ kind: "view", ts, source, visitId });
        continue;
      }

      const mm = parseMaybeLevel(item && (item.m ?? item.level ?? item.mastery));
      if (mm == null) continue;
      out.push({ kind: "mastery", m: mm, ts, source });
    }

    out.sort((a, b) => (Number(a.ts) || 0) - (Number(b.ts) || 0));

    if (!out.some((x) => x.kind === "mastery") && validLevel(currentLevel) && Number(lastReviewed) > 0 && Number(reviewCount) > 0) {
      out.push({ kind: "mastery", m: Number(currentLevel), ts: Number(lastReviewed), source: "legacy" });
    }

    if (Number(lastViewed) > 0) {
      const hasSameView = out.some((x) => x.kind === "view" && Number(x.ts) === Number(lastViewed));
      if (!hasSameView) out.push({ kind: "view", ts: Number(lastViewed), source: "legacy", visitId: "" });
    }

    out.sort((a, b) => (Number(a.ts) || 0) - (Number(b.ts) || 0));
    return out.slice(-HISTORY_LIMIT);
  }

  function viewOnlyHistory(history) {
    return (Array.isArray(history) ? history : [])
      .filter((h) => historyKind(h) === "view" && Number(historyTs(h)) > 0)
      .map((h) => ({
        kind: "view",
        ts: Number(historyTs(h)) || 0,
        source: typeof h.source === "string" ? h.source : "",
        visitId: typeof h.visitId === "string" ? h.visitId : "",
      }))
      .sort((a, b) => (Number(a.ts) || 0) - (Number(b.ts) || 0))
      .slice(-HISTORY_LIMIT);
  }

  function normaliseRecord(rec) {
    const r = rec && typeof rec === "object" ? rec : {};
    const explicitUnrated = r.unrated === true || String(r.state || "").toLowerCase() === "unrated";
    const rawM = (r.m === null || r.m === "") ? null : Number(r.m);
    const m = explicitUnrated ? null : (validLevel(rawM) ? rawM : null);
    const lastReviewed = explicitUnrated ? 0 : (Number(r.lastReviewed) || 0);
    const lastViewed = Math.max(Number(r.lastViewed) || 0, Number(r.lastSeen) || 0, 0);
    const reviewCountRaw = Number(r.reviewCount) || 0;

    let counts = r.counts && typeof r.counts === "object" ? r.counts : null;
    if (!counts) counts = emptyCounts();
    counts = explicitUnrated ? emptyCounts() : {
      full: Number(counts.full) || 0,
      know: Number(counts.know) || 0,
      fuzzy: Number(counts.fuzzy) || 0,
      dont: Number(counts.dont) || 0,
    };

    if (!explicitUnrated && (counts.full + counts.know + counts.fuzzy + counts.dont) === 0 && reviewCountRaw > 0) {
      if (m === M_FULL) counts.full = reviewCountRaw;
      else if (m === M_KNOW) counts.know = reviewCountRaw;
      else if (m === M_FUZZY) counts.fuzzy = reviewCountRaw;
      else if (m === M_DONT) counts.dont = reviewCountRaw;
    }

    const reviewCount = explicitUnrated ? 0 : Math.max(reviewCountRaw, counts.full + counts.know + counts.fuzzy + counts.dont);
    const history = explicitUnrated
      ? viewOnlyHistory(normaliseHistory(r.history || r.reviewHistory || r.masteryHistory, m, lastReviewed, reviewCount, lastViewed))
      : normaliseHistory(r.history || r.reviewHistory || r.masteryHistory, m, lastReviewed, reviewCount, lastViewed);

    const historyViews = history.filter((h) => h.kind === "view").length;
    const viewCount = Math.max(Number(r.viewCount) || 0, reviewCount, historyViews);
    const visitCount = Math.max(Number(r.visitCount) || 0, viewCount, historyViews);
    const visited = !!(r.visited || visitCount > 0 || lastViewed > 0 || historyViews > 0);
    const updatedAt = Math.max(
      Number(r.updatedAt) || 0,
      Number(r.updated_at) || 0,
      Number(r.ts) || 0,
      lastReviewed || 0,
      lastViewed || 0
    );

    return {
      m,
      unrated: explicitUnrated || m == null,
      state: (explicitUnrated || m == null) ? "unrated" : "rated",
      lastReviewed,
      reviewCount,
      viewCount,
      visitCount,
      lastViewed,
      updatedAt,
      visited,
      counts,
      history,
      title: typeof r.title === "string" ? cleanTitle(r.title) : "",
      course: typeof r.course === "string" ? r.course : "",
      coursePath: typeof r.coursePath === "string" ? r.coursePath : "",
    };
  }

  function serialiseRecord(rec) {
    const r = normaliseRecord(rec);
    return {
      m: r.m,
      unrated: r.unrated,
      state: r.state,
      lastReviewed: r.lastReviewed,
      reviewCount: r.reviewCount,
      viewCount: r.viewCount,
      visitCount: r.visitCount,
      lastViewed: r.lastViewed,
      updatedAt: r.updatedAt,
      visited: r.visited,
      counts: { ...r.counts },
      history: Array.isArray(r.history) ? r.history.slice(-HISTORY_LIMIT) : [],
      title: r.title,
      course: r.course,
      coursePath: r.coursePath,
    };
  }

  function get(id) {
    const key = normId(id);
    if (!key) return null;
    const all = safeReadAll();
    if (!all[key]) return null;
    return normaliseRecord(all[key]);
  }

  function wasVisited(id) {
    const rec = get(id);
    return !!(rec && rec.visited);
  }

  function upsertMeta(rec, meta) {
    const m = meta && typeof meta === "object" ? meta : {};
    const out = { ...rec };
    if (typeof m.title === "string" && m.title.trim()) out.title = cleanTitle(m.title);
    if (typeof m.course === "string" && m.course.trim()) out.course = m.course.trim();
    if (typeof m.coursePath === "string" && m.coursePath.trim()) out.coursePath = m.coursePath.trim();
    return out;
  }

  function pushHistory(rec, entry) {
    const arr = Array.isArray(rec.history) ? rec.history.slice() : [];
    arr.push(entry);
    arr.sort((a, b) => (Number(a.ts) || 0) - (Number(b.ts) || 0));
    rec.history = arr.slice(-HISTORY_LIMIT);
    return rec;
  }

  function rate(id, m, meta, opts) {
    const key = normId(id);
    if (!key) return null;
    const mm = Number(m);
    if (!validLevel(mm)) return null;

    const all = safeReadAll();
    const prev = normaliseRecord(all[key]);
    const next = upsertMeta(prev, meta);
    const now = Date.now();
    const source = (opts && typeof opts.source === "string") ? opts.source : "widget";

    next.unrated = false;
    next.state = "rated";
    next.m = mm;
    next.lastReviewed = now;
    next.updatedAt = now;

    if (mm === M_FULL) next.counts.full += 1;
    else if (mm === M_KNOW) next.counts.know += 1;
    else if (mm === M_FUZZY) next.counts.fuzzy += 1;
    else if (mm === M_DONT) next.counts.dont += 1;

    next.reviewCount = next.counts.full + next.counts.know + next.counts.fuzzy + next.counts.dont;
    next.viewCount = Math.max(Number(next.viewCount) || 0, next.reviewCount, 1);
    next.visitCount = Math.max(Number(next.visitCount) || 0, next.viewCount, 1);
    next.visited = true;
    next.lastViewed = Math.max(Number(next.lastViewed) || 0, now);
    pushHistory(next, { kind: "mastery", m: mm, ts: now, source });

    all[key] = serialiseRecord(next);
    safeWriteAll(all);
    notifyChanged(masteryChangeDetail(key, prev, next, source, now, meta, opts));
    return normaliseRecord(all[key]);
  }

  function setLevel(id, m, meta, opts) {
    const key = normId(id);
    if (!key) return null;
    const mm = parseMaybeLevel(m);

    const all = safeReadAll();
    const prev = normaliseRecord(all[key]);
    const next = upsertMeta(prev, meta);
    const now = Date.now();
    const source = (opts && typeof opts.source === "string") ? opts.source : "manager";

    if (mm == null) {
      const viewsOnly = viewOnlyHistory(next.history);
      next.m = null;
      next.unrated = true;
      next.state = "unrated";
      next.lastReviewed = 0;
      next.reviewCount = 0;
      next.counts = emptyCounts();
      next.updatedAt = now;
      next.history = viewsOnly;
      next.visited = !!(next.visited || next.viewCount > 0 || next.visitCount > 0 || next.lastViewed > 0 || viewsOnly.length > 0);
      all[key] = serialiseRecord(next);
      safeWriteAll(all);
      notifyChanged(masteryChangeDetail(key, prev, next, source, now, meta, opts));
      return normaliseRecord(all[key]);
    }

    next.m = mm;
    next.unrated = false;
    next.state = "rated";
    next.lastReviewed = now;
    next.updatedAt = now;
    next.visited = !!(next.visited || next.viewCount > 0 || next.visitCount > 0 || next.lastViewed > 0);
    pushHistory(next, { kind: "mastery", m: mm, ts: now, source });

    all[key] = serialiseRecord(next);
    safeWriteAll(all);
    notifyChanged(masteryChangeDetail(key, prev, next, source, now, meta, opts));
    return normaliseRecord(all[key]);
  }

  function bumpView(id, meta, opts) {
    const key = normId(id);
    if (!key) return null;

    const all = safeReadAll();
    const prev = normaliseRecord(all[key]);
    const next = upsertMeta(prev, meta);
    const now = Date.now();
    const source = (opts && typeof opts.source === "string") ? opts.source : "widget";
    const visitId = (opts && typeof opts.visitId === "string") ? opts.visitId : "";

    if (visitId && Array.isArray(next.history) && next.history.some((h) => h && h.kind === "view" && h.visitId === visitId)) {
      next.visited = true;
      all[key] = serialiseRecord(next);
      safeWriteAll(all);
      notifyChanged({ conceptId: key, path: key, source, ts: now, kind: "view", xpEligible: false });
      return normaliseRecord(all[key]);
    }

    next.viewCount = (Number(next.viewCount) || 0) + 1;
    next.visitCount = (Number(next.visitCount) || 0) + 1;
    next.lastViewed = now;
    next.updatedAt = Math.max(Number(next.updatedAt) || 0, now);
    next.visited = true;
    next.reviewCount = Math.max(Number(next.reviewCount) || 0, (Number(next.counts?.full) || 0) + (Number(next.counts?.know) || 0) + (Number(next.counts?.fuzzy) || 0) + (Number(next.counts?.dont) || 0));
    next.viewCount = Math.max(next.viewCount, next.reviewCount);
    next.visitCount = Math.max(next.visitCount, next.viewCount);
    pushHistory(next, { kind: "view", ts: now, source, visitId });

    all[key] = serialiseRecord(next);
    safeWriteAll(all);
    notifyChanged({ conceptId: key, path: key, source, ts: now, kind: "view", visitId, xpEligible: false });
    return normaliseRecord(all[key]);
  }

  function masteryLevelLabel(mm) {
    if (mm === M_FULL) return "Mastered";
    if (mm === M_KNOW) return "Clear";
    if (mm === M_FUZZY) return "Fuzzy";
    if (mm === M_DONT) return "Unknown";
    return "Not rated";
  }

  function recapTimelineOfRecord(rec, limit) {
    const src = Array.isArray(rec && rec.history) ? rec.history.slice() : [];
    const maxItems = Math.max(3, Math.min(8, Number(limit) || 5));
    const desc = src
      .map((item) => {
        const ts = historyTs(item);
        if (!ts) return null;
        const kind = historyKind(item);
        if (kind === "view") return { kind: "view", ts };
        const mm = parseMaybeLevel(item && (item.m ?? item.level ?? item.mastery));
        if (mm == null) return null;
        return { kind: "mastery", ts, m: mm };
      })
      .filter(Boolean)
      .sort((a, b) => (Number(b.ts) || 0) - (Number(a.ts) || 0));

    const out = [];
    for (const item of desc) {
      if (item.kind === "view") {
        const prev = out[out.length - 1];
        if (
          prev &&
          prev.kind === "view" &&
          (Number(prev.ts) || 0) - (Number(item.ts) || 0) <= 36 * 60 * 60 * 1000
        ) {
          prev.count = (Number(prev.count) || 1) + 1;
          prev.earliestTs = Number(item.ts) || prev.earliestTs || prev.ts;
          continue;
        }
        out.push({ kind: "view", ts: Number(item.ts) || 0, count: 1, earliestTs: Number(item.ts) || 0 });
      } else {
        out.push({ kind: "mastery", ts: Number(item.ts) || 0, m: item.m });
      }
      if (out.length >= maxItems) break;
    }

    return out.map((item) => {
      if (item.kind === "view") {
        const count = Math.max(1, Number(item.count) || 1);
        return {
          kind: "view",
          ts: Number(item.ts) || 0,
          count,
          label: count > 1 ? `Viewed this page ×${count}` : "Viewed this page",
        };
      }
      return {
        kind: "mastery",
        ts: Number(item.ts) || 0,
        m: item.m,
        label: `Rated as ${masteryLevelLabel(item.m)}`,
      };
    });
  }

  function recapInterpretationOfRecord(rec) {
    const history = Array.isArray(rec && rec.history) ? rec.history.slice() : [];
    const masteryEvents = history
      .map((item) => ({
        kind: historyKind(item),
        ts: historyTs(item),
        m: parseMaybeLevel(item && (item.m ?? item.level ?? item.mastery)),
      }))
      .filter((item) => item.ts > 0)
      .sort((a, b) => (Number(a.ts) || 0) - (Number(b.ts) || 0));

    const masteries = masteryEvents.filter((item) => item.kind === "mastery" && item.m != null);
    const views = masteryEvents.filter((item) => item.kind === "view");
    const now = Date.now();
    const lastActivity = Math.max(Number(rec && rec.lastReviewed) || 0, Number(rec && rec.lastViewed) || 0, 0);
    const ageDays = lastActivity > 0 ? Math.max(0, (now - lastActivity) / 86400000) : Infinity;
    const current = parseMaybeLevel(rec && rec.m);
    const recentMasteries = masteries.slice(-3);
    const recentViewBurst = views.filter((item) => now - (Number(item.ts) || 0) <= 14 * 86400000).length;
    const distinctRecent = Array.from(new Set(recentMasteries.map((item) => item.m)));
    const prevMastery = masteries.length >= 2 ? masteries[masteries.length - 2] : null;

    if (!masteries.length && views.length <= 2) {
      return {
        kind: "first-contact",
        title: "First contact",
        text: "This still looks like first contact. Give it a rating after your first serious pass.",
      };
    }

    if (ageDays >= 21 && (views.length + masteries.length) >= 2) {
      return {
        kind: "dormant",
        title: "Dormant",
        text: "You worked on this before, but it has been quiet for a while. A quick refresh would help.",
      };
    }

    if (prevMastery && current != null && prevMastery.m != null && prevMastery.m > current) {
      return {
        kind: "backslide",
        title: "Backslide",
        text: `You recently dropped from ${masteryLevelLabel(prevMastery.m)} to ${masteryLevelLabel(current)}. Revisit the definition and one short example.`,
      };
    }

    if (
      (current == null && views.length >= 3) ||
      ((current === M_FUZZY || current === M_KNOW) && (recentViewBurst >= 2 || distinctRecent.length >= 2))
    ) {
      const text = current == null
        ? "You have revisited this page a few times, but you still have not rated it yet."
        : `You keep coming back, but it is still hovering around ${masteryLevelLabel(current)}.`;
      return {
        kind: "hovering",
        title: "Hovering",
        text,
      };
    }

    if ((current === M_KNOW || current === M_FULL) && recentMasteries.length >= 2 && recentMasteries.every((item) => item.m >= M_KNOW)) {
      return {
        kind: "stable-mastery",
        title: "Stable mastery",
        text: "Your recent ratings have stayed at Clear or Mastered. This looks stable for now.",
      };
    }

    if (current === M_DONT) {
      return {
        kind: "backslide",
        title: "Backslide",
        text: "You most recently marked this as Unknown. Start again from the definition and one basic example.",
      };
    }

    if (current === M_FUZZY) {
      return {
        kind: "hovering",
        title: "Hovering",
        text: "You are engaging with this page, but it is still feeling Fuzzy. One tighter review pass should help.",
      };
    }

    if (current === M_KNOW || current === M_FULL) {
      return {
        kind: "stable-mastery",
        title: "Stable mastery",
        text: `Your current rating is ${masteryLevelLabel(current)}. Keep it warm with a quick revisit before the next lecture or exercise set.`,
      };
    }

    return {
      kind: "first-contact",
      title: "First contact",
      text: "There is only a small amount of history on this page so far.",
    };
  }

  function recapOf(id, opts) {
    const rec = get(id);
    const limit = Math.max(3, Math.min(8, Number(opts && opts.limit) || 5));
    if (!rec) {
      return {
        status: "empty",
        counts: { views: 0, ratings: 0, visits: 0 },
        lastViewed: 0,
        lastReviewed: 0,
        currentLevel: null,
        timeline: [],
        interpretation: null,
      };
    }

    const counts = {
      views: Math.max(0, Number(rec.viewCount) || 0),
      ratings: Math.max(0, Number(rec.reviewCount) || 0),
      visits: Math.max(0, Number(rec.visitCount) || 0),
    };

    const hasActivity = !!(
      rec.visited ||
      counts.views > 0 ||
      counts.ratings > 0 ||
      (Array.isArray(rec.history) && rec.history.length)
    );

    return {
      status: hasActivity ? "ok" : "empty",
      counts,
      lastViewed: Math.max(0, Number(rec.lastViewed) || 0),
      lastReviewed: Math.max(0, Number(rec.lastReviewed) || 0),
      currentLevel: parseMaybeLevel(rec.m),
      timeline: recapTimelineOfRecord(rec, limit),
      interpretation: recapInterpretationOfRecord(rec),
    };
  }

  function clamp(x, lo, hi) {
    x = Number(x);
    if (!Number.isFinite(x)) return lo;
    return Math.min(hi, Math.max(lo, x));
  }

  function scoreFromLevel(mm) {
    if (mm === M_FULL) return SCORE_FULL;
    if (mm === M_KNOW) return SCORE_KNOW;
    if (mm === M_FUZZY) return SCORE_FUZZY;
    if (mm === M_DONT) return SCORE_DONT;
    return 0;
  }

  function multFromScore(score) {
    return Math.exp(SCORE_K * Number(score || 0));
  }

  function confidenceFromTotal(n) {
    const nn = Math.max(0, Number(n) || 0);
    return 1 - Math.exp(-nn / CONF_SCALE);
  }

  function recencyFactor(lastReviewed) {
    const ts = Number(lastReviewed) || 0;
    if (!ts) return 0;
    const ageDays = Math.max(0, (Date.now() - ts) / 86400000);
    return Math.exp(-ageDays / HALF_LIFE_DAYS);
  }

  function scoreFromCounts(counts) {
    const c = counts && typeof counts === "object" ? counts : emptyCounts();
    const full = Number(c.full) || 0;
    const know = Number(c.know) || 0;
    const fuzzy = Number(c.fuzzy) || 0;
    const dont = Number(c.dont) || 0;
    const tot = full + know + fuzzy + dont;
    if (!tot) return 0;
    return (full * SCORE_FULL + know * SCORE_KNOW + fuzzy * SCORE_FUZZY + dont * SCORE_DONT) / tot;
  }

  function computeDynamicWeight(rec) {
    if (!rec || rec.m == null) return UNRATED_WEIGHT;

    const total = Number(rec.reviewCount) || 0;
    const scCounts = scoreFromCounts(rec.counts);
    const longTermMult = multFromScore(scCounts);
    const conf = confidenceFromTotal(total);
    const prior = 1 + (longTermMult - 1) * conf;

    const scNow = scoreFromLevel(rec.m);
    const currentMult = multFromScore(scNow);
    const r = recencyFactor(rec.lastReviewed);
    const blended = prior + (currentMult - prior) * r;

    return clamp(blended, WEIGHT_MIN, WEIGHT_MAX);
  }

  function weightOf(id) {
    return computeDynamicWeight(get(id));
  }

  function filterActive(ids) {
    const arr = Array.isArray(ids) ? ids : [];
    return arr.filter((x) => weightOf(x) > 0);
  }

  function pickWeighted(ids) {
    const arr = Array.isArray(ids) ? ids : [];
    if (!arr.length) return null;

    let total = 0;
    const ws = new Array(arr.length);
    for (let i = 0; i < arr.length; i++) {
      const w = Math.max(0, Number(weightOf(arr[i])) || 0);
      ws[i] = w;
      total += w;
    }
    if (total <= 0) return null;

    let r = Math.random() * total;
    for (let i = 0; i < arr.length; i++) {
      r -= ws[i];
      if (r < 0) return arr[i];
    }
    return arr[arr.length - 1];
  }

  function exportPayload() {
    return safeReadAll();
  }

  function importPayload(payload) {
    if (!payload || typeof payload !== "object") return false;
    const out = {};
    for (const [k, v] of Object.entries(payload)) {
      const nk = normId(k);
      if (!nk) continue;
      out[nk] = serialiseRecord(v);
    }
    safeWriteAll(out);
    notifyChanged();
    return true;
  }

  const GRAPH_URL = "assets/concept-graph.json";
  const READINESS_VISITED_UNRATED = 0.25;
  const READINESS_FUZZY = 0.35;
  const READINESS_KNOW = 0.75;
  const READINESS_FULL = 1;
  const READINESS_DONT = 0;
  const READINESS_DISTANCE_DECAY = 0.62;
  const READINESS_MAX_DEPTH = 4;
  const READINESS_MAX_VISITED = 48;

  function getSiteRootUrl() {
    const script = document.querySelector('script[src*="assets/javascripts/bundle"]');
    const link =
      document.querySelector('link[href*="assets/stylesheets/main"]') ||
      document.querySelector('link[href*="assets/stylesheets"]') ||
      document.querySelector('script[src*="assets/javascripts"]');

    const attr = script ? script.getAttribute("src") : (link ? (link.getAttribute("href") || link.getAttribute("src")) : null);
    const assetUrl = attr ? new URL(attr, document.baseURI) : new URL(document.baseURI);
    const p = assetUrl.pathname || "/";
    const idx = p.indexOf("/assets/");
    if (idx >= 0) return assetUrl.origin + p.slice(0, idx + 1);

    const base = new URL(document.baseURI);
    if (!base.pathname.endsWith("/")) base.pathname += "/";
    return base.origin + base.pathname;
  }

  function ensureSharedJsonFetch() {
    try {
      if (typeof window.__mkFetchJsonShared === "function") return window.__mkFetchJsonShared;
      window.__mkFetchJsonShared = function (url, options) {
        const key = String(url || "");
        if (!key) return Promise.resolve(null);
        if (!window.__mkSharedJsonPromiseMap) window.__mkSharedJsonPromiseMap = Object.create(null);
        const map = window.__mkSharedJsonPromiseMap;
        if (map[key]) return map[key];

        const opts = Object.assign({ credentials: "same-origin" }, options || {});
        const p = fetch(key, opts)
          .then((r) => {
            if (!r || !r.ok) throw new Error(`Failed to fetch JSON: ${key}`);
            return r.json();
          })
          .catch((err) => {
            try { delete map[key]; } catch (_) {}
            throw err;
          });

        map[key] = p;
        return p;
      };
      return window.__mkFetchJsonShared;
    } catch (_) {
      return function (url, options) {
        return fetch(String(url || ""), Object.assign({ credentials: "same-origin" }, options || {})).then((r) => {
          if (!r || !r.ok) throw new Error(`Failed to fetch JSON: ${url}`);
          return r.json();
        });
      };
    }
  }

  const __mkFetchJsonShared = ensureSharedJsonFetch();
  let __cmGraphPromise = null;

  function asStringList(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value.map(String).filter(Boolean);
    if (typeof value === "string") return [value];
    return [];
  }

  function uniqNormalized(list) {
    const out = [];
    const seen = new Set();
    const arr = Array.isArray(list) ? list : [];
    for (const raw of arr) {
      const v = normId(raw);
      if (!v || seen.has(v)) continue;
      seen.add(v);
      out.push(v);
    }
    return out;
  }

  function graphNode(graph, loc) {
    const key = normId(loc);
    if (!graph || !graph.nodes || !key) return null;
    return graph.nodes[key] || graph.nodes[key.replace(/\/+$/, "")] || null;
  }

  function titleFromLoc(loc) {
    const key = normId(loc);
    if (!key) return "";
    try {
      const seg = String(key).split("/").filter(Boolean).pop() || String(key);
      return cleanTitle(decodeURIComponent(seg).replace(/\.html?$/i, "").replace(/[-_]+/g, " "));
    } catch (_) {
      return cleanTitle(key);
    }
  }

  function titleFromGraph(graph, loc) {
    const node = graphNode(graph, loc);
    const direct = cleanTitle((node && (node.title || node.name || node.label)) || "");
    if (direct) return direct;
    return titleFromLoc(loc);
  }

  function normaliseWeight(raw, fallback) {
    const n = Number(raw);
    if (!Number.isFinite(n) || n <= 0) return Number(fallback) || 1;
    return clamp(n, 0.08, 3.0);
  }

  function directWeightMapFromNode(node) {
    const out = Object.create(null);
    if (!node || typeof node !== "object") return out;

    const directObj = node.prerequisiteWeights && typeof node.prerequisiteWeights === "object"
      ? node.prerequisiteWeights
      : (node.prereqWeights && typeof node.prereqWeights === "object" ? node.prereqWeights : null);

    if (directObj) {
      if (Array.isArray(directObj)) {
        for (const entry of directObj) {
          if (!entry) continue;
          if (typeof entry === "string") {
            const id = normId(entry);
            if (id) out[id] = 1;
            continue;
          }
          const loc = normId(entry.loc || entry.path || entry.id || entry.href || "");
          if (!loc) continue;
          out[loc] = normaliseWeight(entry.weight, 1);
        }
      } else {
        for (const [k, v] of Object.entries(directObj)) {
          const id = normId(k);
          if (!id) continue;
          out[id] = normaliseWeight(v, 1);
        }
      }
    }

    const listWeights = Array.isArray(node.prerequisites) ? node.prerequisites : [];
    for (const entry of listWeights) {
      if (!entry || typeof entry !== "object") continue;
      const loc = normId(entry.loc || entry.path || entry.id || entry.href || "");
      if (!loc) continue;
      if (!(loc in out)) out[loc] = normaliseWeight(entry.weight, 1);
    }

    return out;
  }

  function directPrereqsFromNode(node) {
    if (!node || typeof node !== "object") return [];
    const raw =
      node.prerequisites ||
      node.prereqs ||
      node.prerequisite ||
      node.prereq ||
      null;

    if (!raw) return [];

    if (Array.isArray(raw)) {
      const out = [];
      for (const entry of raw) {
        if (!entry) continue;
        if (typeof entry === "string") {
          out.push(entry);
          continue;
        }
        if (typeof entry === "object") {
          const loc = entry.loc || entry.path || entry.id || entry.href || entry.url || "";
          if (loc) out.push(loc);
        }
      }
      return uniqNormalized(out);
    }

    if (typeof raw === "object") {
      return uniqNormalized(Object.keys(raw));
    }

    return uniqNormalized([raw]);
  }

  function getDirectPrereqsFromGraph(graph, loc) {
    const key = normId(loc);
    if (!key || !graph) return [];
    const out = [];

    if (graph.prereqOf && graph.prereqOf[key]) out.push(...asStringList(graph.prereqOf[key]));
    if (graph.prerequisites && graph.prerequisites[key]) out.push(...asStringList(graph.prerequisites[key]));
    if (graph.prereqs && graph.prereqs[key]) out.push(...asStringList(graph.prereqs[key]));

    const node = graphNode(graph, key);
    out.push(...directPrereqsFromNode(node));

    return uniqNormalized(out);
  }

  function getDirectWeightMapFromGraph(graph, loc) {
    const key = normId(loc);
    const out = Object.create(null);
    if (!key || !graph) return out;

    const rootTables = [
      graph.prerequisiteWeights && graph.prerequisiteWeights[key],
      graph.prereqWeights && graph.prereqWeights[key]
    ];

    for (const table of rootTables) {
      if (!table || typeof table !== "object") continue;
      if (Array.isArray(table)) {
        for (const entry of table) {
          if (!entry) continue;
          const id = normId(entry.loc || entry.path || entry.id || entry.href || entry.url || "");
          if (!id) continue;
          out[id] = normaliseWeight(entry.weight, 1);
        }
      } else {
        for (const [k, v] of Object.entries(table)) {
          const id = normId(k);
          if (!id) continue;
          out[id] = normaliseWeight(v, 1);
        }
      }
    }

    const nodeWeights = directWeightMapFromNode(graphNode(graph, key));
    for (const [k, v] of Object.entries(nodeWeights)) {
      if (!(k in out)) out[k] = v;
    }

    return out;
  }

  async function loadConceptGraph() {
    if (__cmGraphPromise) return __cmGraphPromise;

    __cmGraphPromise = (async () => {
      try {
        const url = new URL(GRAPH_URL, getSiteRootUrl()).toString();
        const graph = await __mkFetchJsonShared(url).catch(() => null);
        return graph || null;
      } catch (_) {
        return null;
      }
    })();

    return __cmGraphPromise;
  }

  function readinessValueFromRecord(rec) {
    const r = rec ? normaliseRecord(rec) : null;
    if (!r) return 0;
    if (r.m === M_FULL) return READINESS_FULL;
    if (r.m === M_KNOW) return READINESS_KNOW;
    if (r.m === M_FUZZY) return READINESS_FUZZY;
    if (r.m === M_DONT) return READINESS_DONT;
    if (r.visited) return READINESS_VISITED_UNRATED;
    return 0;
  }

  function readinessLabelFromRecord(rec) {
    const r = rec ? normaliseRecord(rec) : null;
    if (!r) return "Not visited";
    if (r.m === M_FULL) return "Mastered";
    if (r.m === M_KNOW) return "Clear";
    if (r.m === M_FUZZY) return "Fuzzy";
    if (r.m === M_DONT) return "Unknown";
    if (r.visited) return "Visited";
    return "Not visited";
  }

  function readinessBucketFromValue(v) {
    const value = Number(v) || 0;
    if (value >= READINESS_KNOW) return "readyNow";
    if (value >= READINESS_VISITED_UNRATED) return "reviewLightly";
    return "learnFirst";
  }

  function buildReadinessStructure(graph, conceptId, opts) {
    const key = normId(conceptId);
    const o = opts && typeof opts === "object" ? opts : {};
    const maxDepth = Math.max(1, Math.min(8, Number(o.maxDepth) || READINESS_MAX_DEPTH));

    const direct = getDirectPrereqsFromGraph(graph, key);
    const directWeights = getDirectWeightMapFromGraph(graph, key);
    const seenBest = new Map();
    const queue = [];

    for (const loc of direct) {
      const edgeWeight = normaliseWeight(directWeights[loc], 1);
      queue.push({ loc, depth: 1, weight: edgeWeight });
    }

    let visits = 0;
    while (queue.length && visits < READINESS_MAX_VISITED) {
      queue.sort((a, b) => (Number(b.weight) || 0) - (Number(a.weight) || 0));
      const cur = queue.shift();
      visits += 1;

      const loc = normId(cur && cur.loc);
      const depth = Math.max(1, Number(cur && cur.depth) || 1);
      const weight = Math.max(0, Number(cur && cur.weight) || 0);
      if (!loc || loc === key || weight <= 0) continue;

      const prev = seenBest.get(loc);
      if (!prev || weight > prev.rawWeight || (weight === prev.rawWeight && depth < prev.depth)) {
        seenBest.set(loc, {
          loc,
          title: titleFromGraph(graph, loc),
          depth,
          rawWeight: weight,
          isDirect: depth === 1,
        });
      }

      if (depth >= maxDepth) continue;

      const parentWeights = getDirectWeightMapFromGraph(graph, loc);
      const parents = getDirectPrereqsFromGraph(graph, loc);
      for (const parent of parents) {
        const nextLoc = normId(parent);
        if (!nextLoc || nextLoc === key) continue;
        const edgeWeight = normaliseWeight(parentWeights[nextLoc], 1);
        const nextWeight = weight * edgeWeight * READINESS_DISTANCE_DECAY;
        if (nextWeight <= 0.01) continue;
        const best = seenBest.get(nextLoc);
        if (best && best.rawWeight >= nextWeight && best.depth <= depth + 1) continue;
        queue.push({ loc: nextLoc, depth: depth + 1, weight: nextWeight });
      }
    }

    const all = Array.from(seenBest.values()).sort((a, b) => {
      if ((b.rawWeight || 0) !== (a.rawWeight || 0)) return (b.rawWeight || 0) - (a.rawWeight || 0);
      if ((a.depth || 99) !== (b.depth || 99)) return (a.depth || 99) - (b.depth || 99);
      return String(a.title || a.loc || "").localeCompare(String(b.title || b.loc || ""), undefined, { sensitivity: "base" });
    });

    const totalRaw = all.reduce((sum, item) => sum + (Number(item.rawWeight) || 0), 0) || 1;
    const directCount = all.filter((item) => item.depth === 1).length;
    const indirectCount = Math.max(0, all.length - directCount);

    return {
      conceptId: key,
      totalAvailable: all.length,
      selectedCount: all.length,
      directCount,
      indirectCount,
      maxDepth,
      distanceDecay: READINESS_DISTANCE_DECAY,
      items: all.map((item) => ({
        ...item,
        weight: (Number(item.rawWeight) || 0) / totalRaw,
      })),
    };
  }

  async function readinessOf(id, opts) {
    const key = normId(id);
    if (!key) return null;

    const graph = await loadConceptGraph().catch(() => null);
    if (!graph) {
      return {
        status: "unavailable",
        conceptId: key,
        pct: null,
        score: null,
        selectedCount: 0,
        totalAvailable: 0,
        directCount: 0,
        indirectCount: 0,
        items: [],
        groups: { readyNow: [], reviewLightly: [], learnFirst: [] },
      };
    }

    const structure = buildReadinessStructure(graph, key, opts);
    const groups = { readyNow: [], reviewLightly: [], learnFirst: [] };

    if (!structure.items.length) {
      return {
        status: "ok",
        conceptId: key,
        pct: 100,
        score: 1,
        selectedCount: 0,
        totalAvailable: 0,
        directCount: 0,
        indirectCount: 0,
        items: [],
        groups,
        basedOn: "none",
        explain: "This page has no registered prerequisites in the current concept graph.",
      };
    }

    let score = 0;
    for (const base of structure.items) {
      const rec = get(base.loc);
      const value = readinessValueFromRecord(rec);
      const bucket = readinessBucketFromValue(value);
      const item = {
        ...base,
        value,
        stateLabel: readinessLabelFromRecord(rec),
        hasExplicitRating: !!(rec && rec.m != null),
        mastery: rec && typeof rec.m === "number" ? rec.m : null,
        visited: !!(rec && rec.visited),
        weightPct: Math.max(1, Math.round((Number(base.weight) || 0) * 100)),
      };
      score += (Number(base.weight) || 0) * value;
      groups[bucket].push(item);
    }

    const pct = Math.round(clamp(score, 0, 1) * 100);

    for (const bucket of Object.keys(groups)) {
      groups[bucket].sort((a, b) => {
        if ((b.weight || 0) !== (a.weight || 0)) return (b.weight || 0) - (a.weight || 0);
        if ((a.value || 0) !== (b.value || 0)) return (a.value || 0) - (b.value || 0);
        return String(a.title || a.loc || "").localeCompare(String(b.title || b.loc || ""), undefined, { sensitivity: "base" });
      });
    }

    const directCount = Number(structure.directCount) || 0;
    const indirectCount = Number(structure.indirectCount) || 0;
    const totalCount = Number(structure.totalAvailable) || 0;
    const explainParts = [];
    if (totalCount > 0) {
      explainParts.push(`Calculated from all ${totalCount} prerequisite concept${totalCount === 1 ? "" : "s"}.`);
    }
    if (directCount > 0) {
      explainParts.push(`The ${directCount} direct prerequisite${directCount === 1 ? "" : "s"} keep full weight.`);
    }
    if (indirectCount > 0) {
      explainParts.push(`Indirect prerequisites count less as they get farther away.`);
    }

    return {
      status: "ok",
      conceptId: key,
      pct,
      score: clamp(score, 0, 1),
      selectedCount: structure.selectedCount,
      totalAvailable: structure.totalAvailable,
      directCount,
      indirectCount,
      items: structure.items,
      groups,
      basedOn: "all",
      explain: explainParts.join(" ").trim(),
      algorithm: {
        maxDepth: structure.maxDepth,
        distanceDecay: structure.distanceDecay,
        pathRule: "strongest-path",
      },
    };
  }



  window.ConceptMastery = {
    M_FULL,
    M_KNOW,
    M_FUZZY,
    M_DONT,
    normId,
    get,
    wasVisited,
    rate,
    setLevel,
    bumpView,
    weightOf,
    filterActive,
    pickWeighted,
    set: rate,
    _readAll: safeReadAll,
    _writeAll: safeWriteAll,
    _normaliseRecord: normaliseRecord,
    _exportPayload: exportPayload,
    _importPayload: importPayload,
    getSiteRootUrl,
    loadGraph: loadConceptGraph,
    getDirectPrereqs: function (id) {
      return loadConceptGraph().then((graph) => graph ? getDirectPrereqsFromGraph(graph, id) : []);
    },
    readinessValueFromRecord,
    readinessOf,
    recapOf,
  };
})();
