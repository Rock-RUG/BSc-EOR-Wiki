// docs/javascripts/fuzzy-core.js
// Shared fuzzy spell-correction core for Find + Course Search.
// - Candidate retrieval via trigram inverted index
// - Final scoring via OSA Damerau–Levenshtein (early-exit)
// - Supports space mistakes:
//   - missing space: "boumdedzet" -> "bounded set" (split + spell)
//   - extra space: "difg rentiak" -> "differential" (join + spell)
// Safety:
// - Never touch math/symbol/digit tokens (R^n, Z_2, L^p, σ, ℝ, etc.)

(function () {
  const VERSION = "mk-fuzzy-core-v2";

  // -------------------- helpers --------------------
  function normWS(s) {
    return String(s || "").replace(/\s+/g, " ").trim();
  }

  function stripDiacritics(s) {
    try {
      return String(s || "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
    } catch (_) {
      return String(s || "");
    }
  }

  function normAlphaText(s) {
    // keep spaces; collapse everything else to spaces; keep only a-z
    const t = stripDiacritics(s).toLowerCase();
    return t.replace(/[^a-z\s]+/g, " ").replace(/\s+/g, " ").trim();
  }

  function hasDigitsOrNonAsciiOrMathy(s) {
    const x = String(s || "").trim();
    if (!x) return true;
    if (/\d/.test(x)) return true;              // digits
    if (/[^\x00-\x7F]/.test(x)) return true;    // non-ascii (σ, ℝ)
    // symbols used in math/search syntax
    if (/[\\^_{}[\]()<>=:+*/|]/.test(x)) return true;
    return false;
  }

  function splitWords(phrase) {
    const t = normAlphaText(phrase);
    return t ? t.split(" ").filter(Boolean) : [];
  }

  function maxDistByLen(len) {
    if (len <= 4) return 1;
    if (len <= 7) return 2;
    if (len <= 11) return 2;
    return 2;
  }

  // OSA Damerau–Levenshtein with early-exit
  function osaDL(a, b, maxDist) {
    a = String(a || "");
    b = String(b || "");
    const al = a.length, bl = b.length;
    if (!al) return bl;
    if (!bl) return al;
    if (Math.abs(al - bl) > maxDist) return maxDist + 1;

    let prevPrev = new Array(bl + 1);
    let prev = new Array(bl + 1);
    let curr = new Array(bl + 1);

    for (let j = 0; j <= bl; j++) prev[j] = j;

    for (let i = 1; i <= al; i++) {
      curr[0] = i;
      let rowMin = curr[0];
      const ai = a.charCodeAt(i - 1);

      for (let j = 1; j <= bl; j++) {
        const cost = ai === b.charCodeAt(j - 1) ? 0 : 1;

        let v = prev[j] + 1; // del
        const ins = curr[j - 1] + 1;
        if (ins < v) v = ins;
        const sub = prev[j - 1] + cost;
        if (sub < v) v = sub;

        if (
          i > 1 && j > 1 &&
          a.charCodeAt(i - 1) === b.charCodeAt(j - 2) &&
          a.charCodeAt(i - 2) === b.charCodeAt(j - 1)
        ) {
          const trans = prevPrev[j - 2] + 1;
          if (trans < v) v = trans;
        }

        curr[j] = v;
        if (v < rowMin) rowMin = v;
      }

      if (rowMin > maxDist) return maxDist + 1;

      // rotate
      const tmp = prevPrev;
      prevPrev = prev;
      prev = curr;
      curr = tmp;
    }

    return prev[bl];
  }

  function trigrams(word) {
    const w = "^^" + word + "$";
    const out = [];
    for (let i = 0; i <= w.length - 3; i++) out.push(w.slice(i, i + 3));
    return out;
  }

  // -------------------- scope cache --------------------
  const _scopes = new Map();        // scopeKey -> scope
  const _scopePromises = new Map(); // scopeKey -> Promise<scope>

  function buildScope(scopeKey, pageDocs, opts) {
    const o = opts || {};
    const stop = new Set(
      (o.stopwords || [
        "the","and","or","to","of","in","on","for","with","a","an","is","are",
        "from","by","as","at","be","this","that","it"
      ]).map(x => String(x).toLowerCase())
    );

    const freq = new Map();
    const weight = new Map();

    function addWords(text, w) {
      const ws = splitWords(text);
      for (const x of ws) {
        if (x.length < 3) continue;
        if (stop.has(x)) continue;
        freq.set(x, (freq.get(x) || 0) + 1);
        weight.set(x, (weight.get(x) || 0) + (w || 1));
      }
    }

    const docs = Array.isArray(pageDocs) ? pageDocs : [];
    for (const d of docs) {
      addWords(d && d.title, 7);

      const aliases = Array.isArray(d && d.aliases) ? d.aliases : [];
      for (const a of aliases) addWords(a, 6);

      const tags = Array.isArray(d && d.tags) ? d.tags : [];
      for (const t of tags) addWords(String(t).replace(/[-_]/g, " "), 4);

      addWords(String(d && d.location).replace(/[-_/]/g, " "), 2);

      if (o.includeBody && d && d.text) {
        // body is noisy: slice to cap cost
        addWords(String(d.text).slice(0, 8000), 1);
      }
    }

    const minFreq = Number.isFinite(o.minFreq) ? o.minFreq : 2;
    const maxVocab = Number.isFinite(o.maxVocab) ? o.maxVocab : 12000;

    let vocab = [];
    for (const [w, c] of freq.entries()) {
      if (c < minFreq) continue;
      vocab.push(w);
    }

    vocab.sort((a, b) => (weight.get(b) || 0) - (weight.get(a) || 0));
    vocab = vocab.slice(0, maxVocab);

    const wordSet = new Set(vocab);
    const tri = new Map();
    const meta = new Array(vocab.length);

    for (let i = 0; i < vocab.length; i++) {
      const w = vocab[i];
      const uniq = new Set(trigrams(w));
      meta[i] = { w, triCount: uniq.size, weight: weight.get(w) || 0 };
      for (const g of uniq) {
        let arr = tri.get(g);
        if (!arr) { arr = []; tri.set(g, arr); }
        arr.push(i);
      }
    }

    const scope = { scopeKey, version: VERSION, vocab, wordSet, tri, meta };
    _scopes.set(scopeKey, scope);
    return scope;
  }

  async function ensureScope(scopeKey, opts) {
    if (_scopes.has(scopeKey)) return _scopes.get(scopeKey);
    if (_scopePromises.has(scopeKey)) return _scopePromises.get(scopeKey);

    const p = (async () => {
      const o = opts || {};
      if (Array.isArray(o.pageDocs)) {
        return buildScope(scopeKey, o.pageDocs, o);
      }

      // fallback: fetch mkdocs search index
      const rootUrl = o.rootUrl;
      if (!rootUrl) throw new Error("mk-fuzzy-core: rootUrl/pageDocs required");

      const url = new URL("search/search_index.json", rootUrl).toString();
      const res = await fetch(url, { cache: "no-cache" });
      if (!res.ok) throw new Error("mk-fuzzy-core: cannot load index");
      const j = await res.json();
      const docs = j && Array.isArray(j.docs) ? j.docs : [];

      // aggregate section docs -> pages (minimal)
      const pageMap = new Map();
      function safePath(loc) {
        const s0 = String(loc || "");
        return (s0.split("#")[0] || s0).replace(/^\/+/, "");
      }
      function asList(x) {
        if (!x) return [];
        if (Array.isArray(x)) return x.map(String).filter(Boolean);
        if (typeof x === "string") return [x];
        return [];
      }
      function getTagsFromDoc(d) {
        const out = [];
        out.push(...asList(d && d.tags));
        out.push(...asList(d && d.tag));
        out.push(...asList(d && d.meta && d.meta.tags));
        out.push(...asList(d && d.meta && d.meta.tag));
        out.push(...asList(d && d.meta && d.meta["tags"]));
        return out.map(s => String(s).trim()).filter(Boolean);
      }
      function getAliasesFromDoc(d) {
        const out = [];
        out.push(...asList(d && d.aliases));
        out.push(...asList(d && d.alias));
        out.push(...asList(d && d.meta && d.meta.aliases));
        out.push(...asList(d && d.meta && d.meta.alias));
        out.push(...asList(d && d.meta && d.meta["aliases"]));
        return out.map(s => String(s).trim()).filter(Boolean);
      }
      for (const d of docs) {
        const loc = safePath(d && d.location);
        if (!loc) continue;
        const key = loc;
        let e = pageMap.get(key);
        if (!e) {
          e = { location: key, title: "", text: "", tags: new Set(), aliases: new Set() };
          pageMap.set(key, e);
        }
        if (!e.title && d.title) e.title = String(d.title);
        for (const tg of getTagsFromDoc(d)) e.tags.add(tg);
        for (const al of getAliasesFromDoc(d)) e.aliases.add(al);
        if (d.text) e.text += " " + String(d.text);
      }
      const pages = Array.from(pageMap.values()).map(e => ({
        location: e.location,
        title: e.title || "",
        text: e.text || "",
        tags: Array.from(e.tags),
        aliases: Array.from(e.aliases)
      }));

      return buildScope(scopeKey, pages, o);
    })();

    _scopePromises.set(scopeKey, p);
    try {
      const s = await p;
      return s;
    } finally {
      _scopePromises.delete(scopeKey);
    }
  }

  function exists(scope, w) {
    return !!(scope && scope.wordSet && scope.wordSet.has(w));
  }

  function suggestWord(scope, rawWord) {
    const w0 = normAlphaText(rawWord);
    if (!w0 || w0.length < 3) return null;
    if (!/^[a-z]+$/.test(w0)) return null;
    if (exists(scope, w0)) return null;

    const qTris = Array.from(new Set(trigrams(w0)));
    const qTriCount = qTris.length || 1;

    const candCount = new Map();
    for (const g of qTris) {
      const arr = scope.tri.get(g);
      if (!arr) continue;
      for (const idx of arr) candCount.set(idx, (candCount.get(idx) || 0) + 1);
    }
    if (!candCount.size) return null;

    const tmp = [];
    for (const [idx, ov] of candCount.entries()) {
      const m = scope.meta[idx];
      const denom = Math.max(qTriCount, m.triCount || 1);
      const ratio = ov / denom;
      tmp.push({ idx, ratio, weight: m.weight || 0 });
    }

    tmp.sort((a, b) => (b.ratio - a.ratio) || (b.weight - a.weight));
    const topK = tmp.slice(0, 60);

    const maxD = maxDistByLen(w0.length);
    let best = null;

    for (const c of topK) {
      const minRatio = w0.length <= 5 ? 0.34 : 0.24;
      if (c.ratio < minRatio) continue;

      const cand = scope.meta[c.idx].w;
      const d = osaDL(w0, cand, maxD);
      if (d > maxD) continue;

      const score = d * 1000 - Math.round(c.ratio * 100) - (c.weight || 0);
      if (!best || score < best.score) best = { word: cand, score };
    }

    return best ? best.word : null;
  }

  function trySplitIntoTwo(scope, raw) {
    const w0 = normAlphaText(raw).replace(/\s+/g, "");
    if (!w0 || w0.length < 6) return null;

    let best = null;

    for (let i = 3; i <= w0.length - 3; i++) {
      const left = w0.slice(0, i);
      const right = w0.slice(i);

      const sl0 = exists(scope, left) ? left : suggestWord(scope, left);
      let sr0 = exists(scope, right) ? right : suggestWord(scope, right);
      if (!sl0 || !sr0) continue;

      // Prefer singular form if it exists and is close (e.g., "sets" -> "set")
      let sr = sr0;
      try {
        if (sr0.length > 3 && sr0.endsWith("s")) {
          const s1 = sr0.slice(0, -1);
          if (exists(scope, s1)) {
            const dr0 = osaDL(right, sr0, maxDistByLen(right.length));
            const dr1 = osaDL(right, s1, maxDistByLen(right.length));
            // prefer singular if it's not much worse (<= +1 edit)
            if (dr1 <= dr0 + 1) sr = s1;
          }
        }
      } catch (_) {}

      const dl = osaDL(left, sl0, maxDistByLen(left.length));
      const dr = osaDL(right, sr, maxDistByLen(right.length));
      const total = dl + dr;

      if (!best || total < best.total) best = { phrase: sl0 + " " + sr, total };
    }

    return best;
  }

  function suggestPhraseSync(scope, rawPhrase) {
    const raw = normWS(rawPhrase);
    if (!raw) return null;
    if (hasDigitsOrNonAsciiOrMathy(raw)) return null;

    const parts = raw.split(/\s+/).filter(Boolean);
    if (!parts.length) return null;

    // 1) single token
    if (parts.length === 1) {
      const w0 = normAlphaText(parts[0]).replace(/\s+/g, "");
      if (!w0 || w0.length < 3) return null;
      if (exists(scope, w0)) return null;

      const wSug = suggestWord(scope, w0);
      const splitRes = trySplitIntoTwo(scope, w0); // { phrase, total } | null

      if (splitRes && !wSug) {
        return { suggested: splitRes.phrase, changes: [{ from: raw, to: splitRes.phrase, kind: "split" }] };
      }

      if (wSug && !splitRes) {
        return { suggested: wSug, changes: [{ from: raw, to: wSug, kind: "spell" }] };
      }

      if (wSug && splitRes) {
        const dw = osaDL(w0, wSug, maxDistByLen(w0.length));
        // Choose the cheaper transformation; prefer split on ties (more "Google-like" hits)
        if (splitRes.total <= dw) {
          return { suggested: splitRes.phrase, changes: [{ from: raw, to: splitRes.phrase, kind: "split" }] };
        }
        return { suggested: wSug, changes: [{ from: raw, to: wSug, kind: "spell" }] };
      }

      return null;
    }

    // 2) multi parts: per-word
    const normParts = parts.map(p => normAlphaText(p).replace(/\s+/g, ""));
    const missing = normParts.some(w => w.length >= 3 && !exists(scope, w));

    if (!missing) return null;

    const corrected = normParts.slice();
    const changes = [];
    for (let i = 0; i < normParts.length; i++) {
      const w = normParts[i];
      if (w.length < 3) continue;
      if (exists(scope, w)) continue;
      const sug = suggestWord(scope, w);
      if (sug && sug !== w) {
        corrected[i] = sug;
        changes.push({ from: parts[i], to: sug, kind: "spell" });
      }
    }

    if (changes.length) {
      // if now all exist -> accept
      let ok = true;
      for (const w of corrected) {
        if (w.length < 3) continue;
        if (!exists(scope, w)) { ok = false; break; }
      }
      if (ok) return { suggested: corrected.join(" "), changes };
    }

    // 3) join+spell: "difg rentiak" -> "difgrentiak" -> "differential"
    const joined = normParts.join("");
    if (joined.length >= 3 && !exists(scope, joined)) {
      const sugJ = suggestWord(scope, joined);
      if (sugJ) return { suggested: sugJ, changes: [{ from: raw, to: sugJ, kind: "join+spell" }] };
    }

    return null;
  }

  async function suggestPhrase(scopeKey, phrase, opts) {
    const scope = await ensureScope(scopeKey, opts);
    return suggestPhraseSync(scope, phrase);
  }

  // -------------------- API --------------------
  window.__mkFuzzyCore = window.__mkFuzzyCore || {
    VERSION,
    ensureScope,
    suggestPhrase,
  };
})();
